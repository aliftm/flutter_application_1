enum RegisterType {
  COMPANY,
  CUSTOMER,
  NOTSELECTED,
}
