abstract class IEntity {
  Map<String, dynamic> toMap();

  IEntity.fromMap(dynamic map);
}
