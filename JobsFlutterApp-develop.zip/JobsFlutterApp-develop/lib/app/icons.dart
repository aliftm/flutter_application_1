import 'package:flutter/widgets.dart';

class MyFlutterApp {
  MyFlutterApp._();

  static const _kFontFam = 'MyFlutterApp';
  static const String? _kFontPkg = null;

  static const IconData briefcase = IconData(0xe807, fontFamily: _kFontFam, fontPackage: _kFontPkg);
}
